# React native login, register, navigation example

Make sure android studio and emulator must me installed in your pc and all the path variables must be set properly.

Go into the project directory and run 

    npm install
    
after installing dependancies, run 

    react-native run-android
